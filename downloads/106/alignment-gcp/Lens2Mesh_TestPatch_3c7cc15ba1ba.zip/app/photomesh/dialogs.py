"""Processing settings dialogs, progress dialog and preferences."""
from PySide6.QtCore import QSettings
from PySide6.QtGui import QColor, QPalette
from PySide6.QtWidgets import (
    QDialog, QFormLayout, QComboBox, QSpinBox, QCheckBox, QDialogButtonBox,
    QVBoxLayout, QGroupBox, QLabel, QProgressBar, QPlainTextEdit, QPushButton,
    QHBoxLayout, QLineEdit, QTabWidget, QWidget, QMessageBox, QScrollArea)

from .filedialogs import QFileDialog

from . import colmap as cm


def _combo(items, current=None):
    c = QComboBox()
    c.addItems(items)
    if current:
        c.setCurrentText(current)
    return c


class _SettingsDialog(QDialog):
    """Base: General and Advanced settings groups, with OK/Cancel."""

    def __init__(self, title, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(380)
        outer = QVBoxLayout(self)
        body = QWidget()
        self.content_layout = QVBoxLayout(body)
        lay = self.content_layout
        scroll = self.settings_scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(body)
        outer.addWidget(scroll, 1)
        self.setMinimumWidth(560)
        screen = self.screen()
        if screen is not None:
            self.setMaximumHeight(int(screen.availableGeometry().height() * .9))
        self.general = QGroupBox("General")
        self.gform = QFormLayout(self.general)
        self.advanced = QGroupBox("Advanced")
        self.aform = QFormLayout(self.advanced)
        lay.addWidget(self.general)
        lay.addWidget(self.advanced)
        bb = self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        outer.addWidget(bb)

    def accept(self):
        try:
            validator = getattr(self, "validate_settings", None)
            if validator:
                validator()
            region = getattr(self, "region_box", None)
            if region is not None and region.isChecked():
                region.region()
        except (ValueError, OSError) as error:
            QMessageBox.warning(self, self.windowTitle(), str(error))
            return
        super().accept()


class AlignPhotosDialog(_SettingsDialog):
    def __init__(self, parent=None):
        super().__init__("Align Photos", parent)
        self.button_box.button(QDialogButtonBox.Ok).setText("Align")
        self.accuracy = _combo(["High", "Medium", "Low", "Lowest"], "High")
        for index,(label,value) in enumerate((("Full","High"),("Half","Medium"),("Quarter","Low"),("One eighth","Lowest"))):
            self.accuracy.setItemText(index,label); self.accuracy.setItemData(index,value)
        self.generic = QCheckBox("Choose photo pairs by visual similarity")
        self.generic.setChecked(True)
        self.reference = QCheckBox("Use GPS to choose nearby photo pairs")
        from .photo_gps import use_photo_gps
        dataset = getattr(parent, "dataset", None)
        self.photo_gps_on = use_photo_gps(dataset) if dataset is not None else True
        self.mode = _combo(["Fast", "Exhaustive", "Sequential"], "Fast")
        self.mode.setToolTip("Fast: fastpipe pair preselection (GPS + global descriptor + sequence)\n"
                             "with coarse-to-fine alignment. Exhaustive: match all pairs.")
        self.c2f = QCheckBox("Align at low resolution first, then refine")
        self.c2f.setChecked(True)
        self.gform.addRow("Matching mode:", self.mode)
        self.mapper = _combo(["Auto", "Global", "Incremental", "Hierarchical"], "Auto")
        self.mapper.setToolTip("Camera pose estimation:\n"
                               "Auto: integrated global mapper for 100+ photos when available, else Incremental\n"
                               "Global: solve cameras together; actual speed depends on the dataset\n"
                               "Incremental: COLMAP, adds photos one by one (most robust, slow on large sets)\n"
                               "Hierarchical: COLMAP, splits the scene and solves parts in parallel")
        self.gform.addRow("Camera estimation:", self.mapper)
        self.feature_method = _combo(["SIFT", "SIFT + LightGlue", "ALIKED + LightGlue"], "SIFT")
        self.feature_method.setToolTip("SIFT is the tested default. Neural methods require the offline model bundle and a compatible engine; they are checked before processing.")
        self.gform.addRow("Features and matching:", self.feature_method)
        self.neural_warning = QLabel(
            "SIFT + LightGlue and ALIKED + LightGlue may take a long time, "
            "especially on CPU or with many photos.")
        self.neural_warning.setWordWrap(True)
        self.neural_warning.setObjectName("neural_time_warning")
        self.gform.addRow(self.neural_warning)
        def update_neural_warning(*_):
            self.neural_warning.setVisible(self.feature_method.currentText() != "SIFT")
        self.feature_method.currentTextChanged.connect(update_neural_warning)
        update_neural_warning()
        self.gps_frame = QCheckBox("Use photo GPS to locate, scale and orient the model")
        cameras = getattr(dataset, "cameras", [])
        from .engine import gps_frame_available
        from .alignment_reference import HEIGHT_REFERENCES, control_availability
        existing = bool(dataset and (dataset.georef or dataset.aligned_count()))
        ready, reason = gps_frame_available(cameras, getattr(dataset, "crs", ""), respect_legacy_flags=False)
        self.gps_frame.setChecked(ready and self.photo_gps_on and not existing)
        self.gps_frame.setEnabled(ready and self.photo_gps_on)
        self.gps_frame.setToolTip(reason if self.photo_gps_on else "Photo GPS is disabled in Settings.")
        self.gform.addRow(self.gps_frame)
        self.use_gcps = QCheckBox("Use ground control points to locate, scale and orient the model")
        gcp_ready, gcp_reason = control_availability(dataset)
        self.gcp_coordinates = QComboBox()
        project_crs = getattr(dataset, "crs", "")
        current_crs = f"Current ({project_crs or 'local XYZ in metres'})" if len(project_crs) < 60 else "Current project CRS"
        self.gcp_coordinates.addItem(current_crs, None)
        alternate_crs = "LOCAL" if project_crs else "EPSG:4326"
        alternate_ready, alternate_reason = control_availability(dataset, alternate_crs)
        if alternate_ready and alternate_reason != gcp_reason:
            self.gcp_coordinates.addItem("Local survey grid (XYZ in metres)" if project_crs else "WGS84 longitude / latitude",
                                         alternate_crs)
            if not gcp_ready:
                gcp_reason += f" Select the applicable GCP coordinate system. {alternate_reason}"
        self.use_gcps.setEnabled(gcp_ready or alternate_ready)
        self.use_gcps.setToolTip(gcp_reason)
        self.gform.addRow(self.use_gcps)
        coordinates_label = QLabel("GCP coordinate system:")
        self.gform.addRow(coordinates_label, self.gcp_coordinates)
        self.common_heights = QComboBox()
        for label, value in HEIGHT_REFERENCES:
            self.common_heights.addItem(label, value)
        reference_settings = dataset.reference_settings if dataset is not None else {}
        camera_height = reference_settings.get("camera_height_reference")
        if camera_height == reference_settings.get("marker_height_reference"):
            self.common_heights.setCurrentIndex(max(0, self.common_heights.findData(camera_height)))
        self.common_heights.setToolTip("Select only if the photo GPS and GCP heights already share this reference. "
                                       "Heights are not converted.")
        height_label = QLabel("Common height reference:")
        self.gform.addRow(height_label, self.common_heights)
        self.gps_priors = QCheckBox("Also constrain individual camera positions with GPS")
        self.gps_priors.setToolTip("Optional with GPS alone. When GPS and GCPs are selected, the adjustment uses both.")
        def update_reference_controls():
            combined = self.gps_frame.isChecked() and self.use_gcps.isChecked()
            show_coordinates = self.use_gcps.isChecked() and self.gcp_coordinates.count() > 1
            coordinates_label.setVisible(show_coordinates)
            self.gcp_coordinates.setVisible(show_coordinates)
            height_label.setVisible(combined)
            self.common_heights.setVisible(combined)
            self.gps_priors.setEnabled(self.gps_frame.isChecked() and not self.use_gcps.isChecked())
        self.gps_frame.toggled.connect(update_reference_controls)
        self.use_gcps.toggled.connect(update_reference_controls)
        update_reference_controls()
        self.gform.addRow(self.gps_priors)
        self.gform.addRow("Image resolution:", self.accuracy)
        self.gform.addRow(self.c2f)
        self.gform.addRow(self.generic)
        self.gform.addRow(self.reference)
        self.key_limit = QSpinBox(); self.key_limit.setRange(0, 1_000_000); self.key_limit.setSpecialValueText("Engine default"); self.key_limit.setValue(24000)
        self.guided = QCheckBox("Find extra matches using image geometry")
        self.single_camera = QCheckBox("Share lens calibration between compatible photos")
        self.single_camera.setChecked(True)
        from .colmap_io import MODEL_ID
        self.camera_model = QComboBox()
        self.camera_model.addItem("Engine default (preserve existing behavior)", "")
        for name in MODEL_ID:
            self.camera_model.addItem(name, name)
        stored_model = QSettings().value('align/camera_model', '', str)
        self.camera_model.setCurrentIndex(max(0, self.camera_model.findData(stored_model)))
        self.camera_model.setToolTip("Choose a model supported by the lens. Fisheye models are for fisheye lenses; more coefficients need stronger image geometry.")
        self.aform.addRow("Camera model:", self.camera_model)
        self.reported_accuracy = QCheckBox("Use GPS accuracy recorded in photos (confirm units are metres)")
        self.reported_accuracy.setChecked(bool(getattr(parent, 'dataset', None) and parent.dataset.reference_settings.get('reported_gps_accuracy', False)))
        self.reported_accuracy.setToolTip('Opt-in DJI XMP receiver deviations. Missing/invalid values use the project accuracy; RTK status alone is never an accuracy guarantee.')
        self.aform.addRow(self.reported_accuracy)
        self.aform.addRow("Key point limit:", self.key_limit)
        for w in (self.guided, self.single_camera):
            self.aform.addRow(w)
        self.key_limit.setToolTip("Maximum features per image. Engine default omits the override; no hidden fine-stage cap.")
        def feature_limits():
            neural = self.feature_method.currentText() != "SIFT"
            self.key_limit.setMaximum(4096 if neural else 1_000_000)
            self.key_limit.setValue(2048 if neural else 24000)
            update_matching_controls()
        def update_matching_controls():
            fast = self.mode.currentText() == "Fast"
            self.c2f.setEnabled(fast and self.feature_method.currentText() == "SIFT")
            self.generic.setEnabled(fast)
        self.feature_method.currentTextChanged.connect(feature_limits)
        self.mode.currentTextChanged.connect(update_matching_controls)
        update_matching_controls()
        from .workflow_ui import alignment_context
        alignment_context(self, parent)
        palette = self.summary.palette()
        gray = "#afb2b7" if palette.color(QPalette.Window).lightness() < 128 else "#63676e"
        palette.setColor(QPalette.WindowText, QColor(gray))
        self.summary.setPalette(palette)

    def showEvent(self, event):
        super().showEvent(event)
        self.layout().activate()
        scroll = self.settings_scroll
        body = scroll.widget()
        viewport = scroll.maximumViewportSize()
        content_height = max(body.minimumSizeHint().height(), body.layout().totalHeightForWidth(viewport.width()))
        controls_height = self.height() - viewport.height()
        available = self.screen().availableGeometry()
        decoration = max(46, self.frameGeometry().height() - self.height() + 12)
        max_height = available.height() - decoration
        self.setMaximumHeight(max_height)
        self.resize(self.width(), min(max(self.height(), content_height + controls_height + 4), max_height))
        if self.frameGeometry().bottom() > available.bottom():
            self.move(self.x(), max(available.top(), self.y() - (self.frameGeometry().bottom() - available.bottom())))

    def settings(self):
        QSettings().setValue('align/camera_model', self.camera_model.currentData())
        gps = self.gps_frame.isEnabled() and self.gps_frame.isChecked()
        gcps = self.use_gcps.isEnabled() and self.use_gcps.isChecked()
        return {"accuracy": self.accuracy.currentData() or self.accuracy.currentText(),
                "generic": self.generic.isChecked(),
                "mode": self.mode.currentText(),
                "mapper": self.mapper.currentText(),
                "feature_method": self.feature_method.currentText(),
                "gps_frame": gps,
                "use_gcps": gcps,
                "gcp_crs": self.gcp_coordinates.currentData() if gcps else None,
                "common_height_reference": self.common_heights.currentData() if gps and gcps else None,
                "gps_priors": self.gps_priors.isEnabled() and self.gps_priors.isChecked(),
                "reported_gps_accuracy": self.reported_accuracy.isChecked(),
                "coarse_to_fine": self.c2f.isEnabled() and self.c2f.isChecked(),
                "reference": self.reference.isEnabled() and self.reference.isChecked(),
                "key_point_limit": self.key_limit.value(),
                "guided_matching": self.guided.isChecked(),
                "single_camera": self.single_camera.isChecked(),
                "camera_model": self.camera_model.currentData(),
                "calibration_groups": getattr(self, "calibration_groups", {}),
                "use_gpu": QSettings().value("gpu/use_gpu", True, bool) and _gpu_ok()}


class BuildPointCloudDialog(_SettingsDialog):
    def __init__(self, parent=None):
        super().__init__("Build Point Cloud", parent)

        self.source = QLabel("Depth maps (CUDA)")
        self.quality = _combo(cm.QUALITY, "Medium")
        self.gform.addRow("Source data:", self.source)
        self.gform.addRow("Quality:", self.quality)
        self.filtering = _combo(cm.DEPTH_FILTERING, "Mild")
        self.confidence = QCheckBox("Filter by supporting-photo count"); self.confidence.setChecked(True)
        self.reuse = QCheckBox("Reuse depth maps")
        self.keep_depth = QCheckBox("Keep depth maps")
        self.keep_depth.setToolTip("Keep the depth maps after the point cloud is built (needed for 'Reuse "
                                   "depth maps'). They are large: at Ultra high about 16 bytes per photo "
                                   "pixel, e.g. ~200 GB for 640 photos of 20 MPix.")
        self.aform.addRow("Depth filtering:", self.filtering)
        for w in (self.confidence, self.reuse, self.keep_depth):
            self.aform.addRow(w)
        self.sources = QSpinBox(); self.sources.setRange(2, 30); self.sources.setValue(8)
        self.step = _combo(["1 (slow, finest)", "2 (fast, default)"], "2 (fast, default)")
        self.iters = QSpinBox(); self.iters.setRange(1, 10); self.iters.setValue(3)
        self.aform.addRow("Neighbour photos per depth map:", self.sources)
        self.aform.addRow("Matching window step:", self.step)
        self.aform.addRow("PatchMatch iterations:", self.iters)
        self.outl = QGroupBox("Outlier filtering"); f = QFormLayout(self.outl)
        self.min_conf = QSpinBox(); self.min_conf.setRange(0, 50); self.min_conf.setValue(3)
        self.sor = QCheckBox("Statistical outlier removal"); self.sor.setChecked(True)
        self.radius = QCheckBox("Radius outlier removal"); self.radius.setChecked(True)
        self.elev = QCheckBox("Remove points far above/below the terrain"); self.elev.setChecked(False)
        f.addRow("Minimum supporting photos:", self.min_conf)
        self.confidence.toggled.connect(self.min_conf.setEnabled)
        for w in (self.sor, self.radius, self.elev):
            f.addRow(w)
        self.content_layout.insertWidget(2, self.outl)
        from .workflow_ui import dense_context
        dense_context(self, parent)

    def settings(self):
        result = {"quality": self.quality.currentText(),
                "depth_filtering": self.filtering.currentText(),
                "reuse": self.reuse.isChecked(),
                "keep_depth_maps": self.keep_depth.isChecked(),
                "max_sources": self.sources.value(),
                "window_step": 1 if self.step.currentIndex() == 0 else 2,
                "num_iterations": self.iters.value(),
                "filters": {"min_confidence": self.min_conf.value() if self.confidence.isChecked() else 0,
                            "statistical": self.sor.isChecked(), "radius": self.radius.isChecked(),
                            "elevation": self.elev.isChecked(), "local_ratio": self.local_ratio.value(),
                            "elevation_k": self.elevation_k.value(),
                            "elevation_min_dev": self.elevation_dev.value() or None}}
        mode = self.up_mode.currentText()
        if mode != "Camera-derived up":
            vector = [0.,0.,1.] if mode == "Project Z" else [v.value() for v in self.up_values]
            if sum(v*v for v in vector) < 1e-12:
                raise ValueError("Terrain up direction cannot be zero")
            result["filters"]["up"] = vector
        return result


class BuildModelDialog(_SettingsDialog):
    def __init__(self, parent=None):
        super().__init__("Build Model", parent)
        from PySide6.QtWidgets import QDoubleSpinBox
        self.source = _combo(["Point cloud", "Depth maps"], "Point cloud")
        self.face_count = _combo(["High", "Medium", "Low", "Custom"], "Medium")
        self.custom = QSpinBox(); self.custom.setRange(1000, 200_000_000); self.custom.setValue(1_000_000)
        self.custom.setSingleStep(100000)
        self.gform.addRow("Source data:", self.source)
        self.gform.addRow("Face count:", self.face_count)
        self.gform.addRow("Custom face count:", self.custom)
        self.custom.setEnabled(False)
        self.face_count.currentTextChanged.connect(lambda text: self.custom.setEnabled(text == "Custom"))
        self.interp = _combo(["Disabled", "Enabled (default)", "Extrapolated"], "Enabled (default)")
        self.voxel = QDoubleSpinBox(); self.voxel.setDecimals(3); self.voxel.setRange(0, 1000)
        self.voxel.setSpecialValueText("Auto (target point count)")
        self.max_pts = QSpinBox(); self.max_pts.setRange(100_000, 100_000_000); self.max_pts.setValue(12_000_000)
        self.max_pts.setSingleStep(1_000_000)
        self.small = QDoubleSpinBox(); self.small.setRange(0, 50); self.small.setValue(1.0); self.small.setSuffix(" % of largest")
        self.long_edge = QDoubleSpinBox(); self.long_edge.setRange(0, 100); self.long_edge.setValue(8.0)
        self.long_edge.setSuffix(" x median edge"); self.long_edge.setSpecialValueText("Off")
        self.aform.addRow("Unsupported-surface trimming:", self.interp)
        self.aform.addRow("Voxel downsample:", self.voxel)
        self.aform.addRow("Max points for meshing:", self.max_pts)
        self.aform.addRow("Remove components smaller than:", self.small)
        self.aform.addRow("Longest face-edge median multiplier:", self.long_edge)
        from .workflow_ui import mesh_context
        mesh_context(self, parent)

    def settings(self):
        return {"source": "Point cloud" if self.source.currentIndex() == 0 else "Depth maps",
                "face_count": self.face_count.currentText(),
                "custom_faces": self.custom.value(),
                "interpolation": ["Disabled", "Enabled", "Extrapolated"][self.interp.currentIndex()],
                "voxel": self.voxel.value() or None, "max_points": self.max_pts.value(),
                "min_component": self.small.value() / 100.0, "min_component_faces": self.component_faces.value(),
                "long_edge_factor": self.long_edge.value(), "n_points": self.input_points}


class FilterPointCloudDialog(_SettingsDialog):
    """Process > Filter Point Cloud > Filter Point Cloud / Filter by Confidence."""
    def __init__(self, parent=None, confidence_only=False):
        super().__init__("Filter by Confidence" if confidence_only else "Filter Point Cloud", parent)
        from PySide6.QtWidgets import QDoubleSpinBox
        self.min_conf = QSpinBox(); self.min_conf.setRange(0, 255); self.min_conf.setValue(3)
        self.max_conf = QSpinBox(); self.max_conf.setRange(1, 65535); self.max_conf.setValue(65535)
        self.gform.addRow("Minimum confidence:", self.min_conf)
        self.gform.addRow("Maximum confidence:", self.max_conf)
        self.sor = QCheckBox("Statistical outlier removal"); self.sor.setChecked(not confidence_only)
        self.k = QSpinBox(); self.k.setRange(4, 100); self.k.setValue(16)
        self.std = QDoubleSpinBox(); self.std.setRange(0.5, 10); self.std.setValue(2.0)
        self.radius = QCheckBox("Radius outlier removal"); self.radius.setChecked(not confidence_only)
        self.rmin = QSpinBox(); self.rmin.setRange(1, 100); self.rmin.setValue(4)
        self.rval = QDoubleSpinBox(); self.rval.setDecimals(4); self.rval.setRange(0, 1e6)
        self.rval.setSpecialValueText("Auto (3x point spacing)")
        self.elev = QCheckBox("Remove points far above/below the terrain")
        for w in (self.sor,):
            self.aform.addRow(w)
        self.aform.addRow("Neighbours (k):", self.k); self.aform.addRow("Std ratio:", self.std)
        self.aform.addRow(self.radius)
        self.aform.addRow("Radius:", self.rval); self.aform.addRow("Min neighbours:", self.rmin)
        self.aform.addRow(self.elev)
        self.advanced.setVisible(not confidence_only)

    def settings(self):
        return {"min_confidence": self.min_conf.value(), "max_confidence": self.max_conf.value(),
                "statistical": self.sor.isChecked(), "sor_k": self.k.value(), "sor_std": self.std.value(),
                "radius": self.radius.isChecked(), "radius_min": self.rmin.value(),
                "radius_value": self.rval.value() or None, "elevation": self.elev.isChecked()}


class GradualSelectionDialog(QDialog):
    """Select (and delete) tie points by reprojection error, reconstruction
    uncertainty, image count or projection accuracy."""
    def __init__(self, metrics, parent=None):
        super().__init__(parent)
        from PySide6.QtWidgets import QDoubleSpinBox
        from .pcfilter import CRITERIA, gradual_select
        self.setWindowTitle("Gradual Selection")
        self.metrics = metrics
        self._sel = gradual_select
        lay = QVBoxLayout(self); f = QFormLayout()
        self.crit = _combo([c for c in CRITERIA if c in metrics])
        self.level = QDoubleSpinBox(); self.level.setDecimals(3); self.level.setRange(0, 1e9)
        self.info = QLabel()
        f.addRow("Criterion:", self.crit); f.addRow("Level:", self.level); f.addRow(self.info)
        lay.addLayout(f)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Delete selected")
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject); lay.addWidget(bb)
        self.crit.currentTextChanged.connect(self._crit); self.level.valueChanged.connect(self._update)
        self._crit(self.crit.currentText())

    def _crit(self, c):
        import numpy as np
        v = self.metrics[c]
        self.level.setValue(3 if c == "Image count" else float(np.percentile(v, 90)) if len(v) else 0)
        self._update()

    def selection(self):
        return self._sel(self.metrics, self.crit.currentText(), self.level.value())

    def _update(self, *_):
        s = self.selection()
        self.info.setText(f"{int(s.sum()):,} of {len(s):,} tie points selected")


class OptimizeCamerasDialog(_SettingsDialog):
    """Process > Optimize Cameras: georeference with markers / camera GPS and
    run the GCP-constrained bundle adjustment."""
    def __init__(self, parent=None, settings=None):
        super().__init__("Optimize Cameras", parent)
        self.setMinimumWidth(760)
        from PySide6.QtWidgets import QDoubleSpinBox
        from .georef import DEFAULTS
        s = dict(DEFAULTS); s.update(settings or {})
        self.use_markers = QCheckBox("Use GCPs (XYZ + placements on 2 or more aligned photos)")
        self.use_markers.setChecked(bool(s.get("use_markers", True)))
        self.use_markers.setToolTip("Unchecked excludes GCP coordinates and image observations from optimization. "
                                    "GCP estimates/errors can still be displayed for checking. Predictions alone are display hints; pin or refine placements on photos before adjustment. "
                                    "At least 3 non-collinear controls are needed to georeference. "
                                   "Without sufficient reference data, local bundle adjustment is offered.")
        self.use_cameras = QCheckBox("Use camera GPS (geographic or supported metre-based CRS)")
        from .photo_gps import use_photo_gps
        dataset = getattr(parent, "dataset", None)
        gps_on = use_photo_gps(dataset) if dataset is not None else True
        self._photo_gps_enabled = gps_on
        self.use_cameras.setChecked(bool(s.get("use_cameras", False)) and gps_on)
        self.use_cameras.setEnabled(gps_on)
        self.use_cameras.setToolTip("Uses valid GPS from enabled photos when Use Photo GPS is enabled in Settings.")
        self.bundle = QCheckBox("Bundle adjustment (otherwise similarity transform only)"); self.bundle.setChecked(True)
        self.intr = QCheckBox("Fit camera calibration (focal lengths, principal point and distortion)"); self.intr.setChecked(True)
        self.intr.setToolTip("Preserves each camera model and fits its supported calibration parameters.")
        for w in (self.use_markers, self.use_cameras, self.bundle, self.intr):
            self.gform.addRow(w)
        self.control_coordinates = QComboBox()
        project_crs = getattr(dataset, "crs", "") or "Local"
        current_label = f"Current project reference ({project_crs})" if len(project_crs) < 60 else "Current project reference"
        self.control_coordinates.addItem(current_label, "current")
        self.control_coordinates.addItem("Local survey grid (XYZ in metres)", "local")
        self.control_coordinates.setToolTip(
            "Choose the coordinate system of the entered control XYZ. Use the local grid "
            "after GPS alignment only if the control coordinates are already in that grid.")
        self.gform.addRow("Control coordinates:", self.control_coordinates)
        self.local_control_note = QLabel(
            "Fit the existing alignment to the local grid using at least three non-collinear controls. "
            "Camera GPS and the previous map origin are excluded from this fit.")
        self.local_control_note.setWordWrap(True)
        self.gform.addRow(self.local_control_note)
        def dspin(v, dec=3, mx=1000):
            w = QDoubleSpinBox(); w.setDecimals(dec); w.setRange(0.0001, mx); w.setValue(v); return w
        self.cam_acc = dspin(s["camera_accuracy"]); self.cam_acc_z = dspin(s["camera_accuracy_z"])
        self.mk_acc = dspin(s["marker_accuracy"], 4); self.mk_acc_z = dspin(s["marker_accuracy_z"], 4)
        self.proj_acc = dspin(s["projection_accuracy"], 2, 50); self.tie_acc = dspin(s["tie_accuracy"], 2, 50)
        self.ties = QSpinBox(); self.ties.setRange(1000, 1_000_000); self.ties.setValue(40000); self.ties.setSingleStep(10000)
        self.reported_accuracy = QCheckBox('Use reported photo GPS deviations (confirm units are metres)')
        self.reported_accuracy.setChecked(bool(s.get('reported_gps_accuracy', False)))
        self.reported_accuracy.setEnabled(gps_on)
        self.reported_accuracy.setToolTip('Valid per-photo E/N/height deviations override the fallback accuracy below. Unknown or inconsistent metadata uses the fallback. No vertical datum conversion is automatic.')
        self.aform.addRow(self.reported_accuracy)
        self.aform.addRow("Fallback camera accuracy XY / Z (m):", _pair(self.cam_acc, self.cam_acc_z))
        self.aform.addRow("GCP accuracy XY / Z (m):", _pair(self.mk_acc, self.mk_acc_z))
        self.aform.addRow("GCP projection accuracy (px):", self.proj_acc)
        self.aform.addRow("Tie point accuracy (px):", self.tie_acc)
        self.aform.addRow("Tie points used in adjustment:", self.ties)
        preset = s.get('intrinsics', 'f,cx,cy,k1-k3,p1,p2')
        self.intrinsic_preset = _combo(['f', 'f,cx,cy,k1', 'f,cx,cy,k1-k3', 'f,cx,cy,k1-k3,p1,p2', 'All supported coefficients'],
                                      'All supported coefficients' if preset == 'all' else preset)
        self.intrinsic_preset.setToolTip('Only named coefficients supported by each existing camera model are fitted. Other coefficients are held fixed.')
        self.intr.toggled.connect(self.intrinsic_preset.setEnabled)
        self.aform.addRow('Fit calibration parameters:', self.intrinsic_preset)
        self.adjustment_frame = QComboBox()
        self.adjustment_frame.addItem('Projected / existing Cartesian frame', 'projected')
        self.adjustment_frame.addItem('WGS84 local ENU (ellipsoidal heights required)', 'enu')
        self.adjustment_frame.setCurrentIndex(1 if (getattr(dataset, 'georef', {}) or {}).get('coordinate_frame') else 0)
        self.aform.addRow('Adjustment frame:', self.adjustment_frame)
        self.height_references = {}
        from .alignment_reference import HEIGHT_REFERENCES
        for key, label in [('camera', 'Photo GPS height reference:'), ('marker', 'Control height reference:')]:
            box = QComboBox()
            for text, value in HEIGHT_REFERENCES:
                box.addItem(text, value)
            box.setCurrentIndex(max(0, box.findData(s.get(key + '_height_reference', 'unknown'))))
            self.height_references[key] = box
            self.aform.addRow(label, box)
        note = QLabel('No geoid or vertical-datum conversion is applied automatically. ENU Up is relative to its tangent origin, not absolute elevation.')
        note.setWordWrap(True)
        self.aform.addRow(note)
        self.use_markers.toggled.connect(self._update_control_coordinates)
        self.control_coordinates.currentIndexChanged.connect(self._update_control_coordinates)
        self._update_control_coordinates()

    def _local_controls(self):
        return self.use_markers.isChecked() and self.control_coordinates.currentData() == "local"

    def _update_control_coordinates(self):
        local = self._local_controls()
        self.control_coordinates.setEnabled(self.use_markers.isChecked())
        self.local_control_note.setVisible(local)
        self.use_cameras.setEnabled(self._photo_gps_enabled and not local)
        self.reported_accuracy.setEnabled(self._photo_gps_enabled and not local)
        self.adjustment_frame.setEnabled(not local)

    def settings(self):
        local = self._local_controls()
        return {"use_markers": self.use_markers.isChecked(), "use_cameras": self.use_cameras.isChecked() and not local,
                "local_control_grid": local,
                "bundle": self.bundle.isChecked(), "fit_intrinsics": self.intr.isChecked(),
                "tie_points": self.ties.value(),
                "adjustment_frame": "projected" if local else self.adjustment_frame.currentData(),
                "intrinsics": 'all' if self.intrinsic_preset.currentText() == 'All supported coefficients' else self.intrinsic_preset.currentText(),
                "reported_gps_accuracy": self.reported_accuracy.isChecked() and self.use_cameras.isChecked(),
                "camera_height_reference": self.height_references['camera'].currentData(),
                "marker_height_reference": self.height_references['marker'].currentData(),
                "accuracies": {"camera_accuracy": self.cam_acc.value(), "camera_accuracy_z": self.cam_acc_z.value(),
                               "marker_accuracy": self.mk_acc.value(), "marker_accuracy_z": self.mk_acc_z.value(),
                               "projection_accuracy": self.proj_acc.value(), "tie_accuracy": self.tie_acc.value()}}


def _pair(a, b):
    w = QWidget(); l = QHBoxLayout(w); l.setContentsMargins(0, 0, 0, 0); l.addWidget(a); l.addWidget(b)
    return w


class BuildTextureDialog(_SettingsDialog):
    """Process > Build Texture (Metashape-like options, see texture.py)."""
    def __init__(self, parent=None, has_uv=False):
        super().__init__("Build Texture", parent)
        st = QSettings()
        self.ttype = QLabel("Diffuse map")
        self.source = QLabel("Images")
        self.mapping = _combo(["Generic", "Adaptive orthophoto", "Orthophoto"] + (["Keep uv"] if has_uv else []),
                              st.value("texture/mapping", "Generic", str))
        self.blending = _combo(["Mosaic (default)", "Average", "Max intensity", "Min intensity", "Single photo (no colour blending)"],
                               st.value("texture/blending", "Mosaic (default)", str))
        self.size = _combo(["1024", "2048", "4096", "8192", "16384"], st.value("texture/size", "8192", str))
        self.size.setEditable(True)
        self.count = QSpinBox(); self.count.setRange(1, 64); self.count.setValue(st.value("texture/count", 1, int))
        row = QWidget(); hl = QHBoxLayout(row); hl.setContentsMargins(0, 0, 0, 0)
        hl.addWidget(self.size, 1); hl.addWidget(QLabel("x")); hl.addWidget(self.count)
        self.gform.addRow("Texture type:", self.ttype)
        self.gform.addRow("Source data:", self.source)
        self.gform.addRow("Mapping mode:", self.mapping)
        self.gform.addRow("Blending mode:", self.blending)
        self.gform.addRow("Texture size/count:", row)
        self.holes = QCheckBox("Enable hole filling"); self.holes.setChecked(st.value("texture/holes", True, bool))
        self.ghost = QCheckBox("Enable ghosting filter"); self.ghost.setChecked(st.value("texture/ghost", True, bool))
        self.res = _combo(["Max side 2640 px (fast)", "Full resolution"],
                          st.value("texture/res", "Working resolution (2640 px, fast)", str))
        self.fmt = _combo(["JPEG", "PNG"], st.value("texture/format", "JPEG", str))
        self.aform.addRow(self.holes); self.aform.addRow(self.ghost)
        self.aform.addRow("Photo resolution:", self.res)
        self.aform.addRow("Texture file format:", self.fmt)
        from .workflow_ui import texture_context
        texture_context(self, parent, has_uv)

    def settings(self):
        st = QSettings()
        for k, w in (("mapping", self.mapping), ("blending", self.blending), ("size", self.size),
                     ("res", self.res), ("format", self.fmt)):
            st.setValue(f"texture/{k}", w.currentText())
        st.setValue("texture/count", self.count.value())
        st.setValue("texture/holes", self.holes.isChecked()); st.setValue("texture/ghost", self.ghost.isChecked())
        try:
            size = int(self.size.currentText())
        except ValueError:
            raise ValueError("Texture size must be an integer between 256 and 32768")
        return {"mapping": self.mapping.currentText(), "blending": self.blending.currentText().replace(" (default)", "").replace("Single photo (no colour blending)", "Disabled"),
                "size": size, "count": self.count.value(), "hole_filling": self.holes.isChecked(),
                "ghosting": self.ghost.isChecked(), "max_res": 0 if self.res.currentIndex() == 1 else 2640,
                "page_policy": "auto" if self.auto_pages.isChecked() else "limit",
                "format": "png" if self.fmt.currentText() == "PNG" else "jpg"}


class BuildTiledModelDialog(_SettingsDialog):
    """Process > Build Tiled Model (see tiles.py)."""
    def __init__(self, parent=None, sources=("Model",), default_pixel=0.0, unit="m"):
        super().__init__("Build Tiled Model", parent)
        from PySide6.QtWidgets import QDoubleSpinBox
        st = QSettings()
        self.source = _combo(list(sources), st.value("tiles/source", sources[0], str))
        self.pixel = QDoubleSpinBox(); self.pixel.setDecimals(4); self.pixel.setRange(0, 1e6)
        self.pixel.setSpecialValueText("Auto (texture resolution)"); self.pixel.setValue(0)
        self.pixel.setSuffix(f" {unit}")
        self.tile_faces = QSpinBox(); self.tile_faces.setRange(2000, 1_000_000); self.tile_faces.setSingleStep(10000)
        self.tile_faces.setValue(st.value("tiles/tile_faces", 60000, int))
        self.max_tex = _combo(["512", "1024", "2048", "4096"], st.value("tiles/max_tex", "2048", str))
        self.fmt = _combo(["Cesium 3D Tiles 1.0 (b3dm)", "Cesium 3D Tiles 1.1 (glb)"],
                          st.value("tiles/format", "Cesium 3D Tiles 1.0 (b3dm)", str))
        self.gform.addRow("Source data:", self.source)
        self.gform.addRow("Pixel size:", self.pixel)
        self.gform.addRow("Tile format:", self.fmt)
        self.aform.addRow("Faces / points per tile:", self.tile_faces)
        self.aform.addRow("Max tile texture size:", self.max_tex)
        from .workflow_ui import tiles_context
        tiles_context(self, parent)

    def settings(self):
        st = QSettings()
        st.setValue("tiles/source", self.source.currentText()); st.setValue("tiles/tile_faces", self.tile_faces.value())
        st.setValue("tiles/max_tex", self.max_tex.currentText()); st.setValue("tiles/format", self.fmt.currentText())
        return {"source": self.source.currentText(), "pixel_size": self.pixel.value(),
                "tile_faces": self.tile_faces.value(), "tile_points": self.tile_faces.value(),
                "max_tex": int(self.max_tex.currentText()),
                "format": "pnts" if self.source.currentText() == "Point cloud" else ("glb" if "glb" in self.fmt.currentText() else "b3dm")}


class ProgressDialog(QDialog):
    """Modal-ish processing progress window with log output and Cancel."""

    def __init__(self, title, parent=None):
        super().__init__(parent)
        self.setProperty("task_progress", True)
        self.setWindowTitle(title)
        self.setMinimumSize(520, 320)
        lay = QVBoxLayout(self)
        self.stage = QLabel("Starting...")
        self.stage.setWordWrap(True)
        self.bar = QProgressBar(); self.bar.setRange(0, 1000)       # 0.1 % steps
        self.bar.setFormat("%p%")
        from .progress import WorkProgress
        from PySide6.QtCore import QTimer
        self._meter = WorkProgress()
        self._stage_text = ""
        self._meter_phase = None
        self.stage_bar = QProgressBar(); self.stage_bar.setRange(0, 0)
        self.stage_bar.setFormat("Current task: %p%")
        self.bar.hide()  # Single tasks have no separate overall work counter.
        self.timing = QLabel("Estimating remaining time..."); self.timing.setWordWrap(True)
        self._timer = QTimer(self); self._timer.setInterval(1000)
        self._timer.timeout.connect(self._refresh_timing)
        self.finished.connect(self._timer.stop)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(2000)
        self.cancel_btn = QPushButton("Cancel")
        lay.addWidget(self.stage)
        lay.addWidget(self.bar)
        self.bar.setFormat("Overall (weighted estimate): %p%")
        lay.addWidget(self.stage_bar)
        lay.addWidget(self.timing)
        lay.addWidget(self.log, 1)
        row = QHBoxLayout(); row.addStretch(1); row.addWidget(self.cancel_btn)
        lay.addLayout(row)
        self.running = True
        self._label, self._detail, self._pct = "", "", 0.0

    def _refresh_timing(self):
        detail = self._stage_text if self._stage_text not in (self._label, self._detail) else ""
        self.timing.setText((detail + "\n" if detail else "") +
                            "Current task: " + self._meter.text(show_counts=False))

    def set_operation_steps(self, count):
        self.bar.setVisible(count > 1)

    def begin_stage(self):
        self._meter.reset()
        self._meter_phase = None
        self._unknown_stage = True
        self.stage_bar.setRange(0, 0)
        self._stage_text = ""

    def finish_success(self):
        """Called only after the result has been published successfully."""
        self._pct = 100.0
        self.bar.setValue(1000)
        self.stage_bar.setRange(0, 1000)
        self.stage_bar.setValue(1000)
        self.stage.setText("Finished")

    def showEvent(self, event):
        super().showEvent(event)
        if self.running:
            self._timer.start()

    def hideEvent(self, event):
        self._timer.stop()
        super().hideEvent(event)

    def reject(self):
        if self.running:
            self.cancel_btn.click()
            self.stage.setText("Cancelling - waiting for the current operation to stop...")
        else:
            super().reject()

    def closeEvent(self, event):
        if self.running:
            self.reject(); event.ignore()
        else:
            event.accept()

    def _show(self):
        txt = self._label or "Starting..."
        if self._detail:
            txt += f"\n{self._detail}"
        self.stage.setText(txt)

    def set_progress(self, pct, label):
        """Step progress (int %); never moves the bar backwards (a retried
        step adds weight to the total)."""
        if label != self._label:
            self._label, self._detail = label, ""
        self._pct = max(self._pct, min(99.9, float(pct)))
        if pct >= 100:
            self._label = "Finalizing results..."
        self.bar.setValue(int(round(self._pct * 10)))
        self._show()

    def set_stage_progress(self, fraction, text):
        if text.startswith("Depth maps: ") and " pass " in text:
            phase = text.split(" pass ", 1)[0]
            if self._meter_phase is not None and phase != self._meter_phase:
                self._meter.reset()
            self._meter_phase = phase
        self._stage_text = text.split(" - about ", 1)[0]
        if fraction < 0:
            if not getattr(self, "_unknown_stage", False):
                self._meter.reset()
            self._unknown_stage = True
            self.stage_bar.setRange(0, 0)
        else:
            self._unknown_stage = False
            self._meter.update(fraction * 1000, 1000)
            self.stage_bar.setRange(0, 1000)
            self.stage_bar.setValue(min(999, int(fraction * 1000)))
        self._refresh_timing()

    def set_detail(self, pct, text):
        """Fine progress inside a step: e.g. depth-map pass, view and ETA."""
        self._pct = max(self._pct, min(99.9, float(pct)))
        self._detail = text.split(" - about ", 1)[0]
        self.bar.setValue(int(round(self._pct * 10)))
        self._show()

    def append(self, line):
        self.log.appendPlainText(line)


class PreferencesDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Preferences")
        self.setMinimumWidth(460)
        s = QSettings()
        lay = QVBoxLayout(self)
        tabs = QTabWidget()
        gen = QWidget(); gf = QFormLayout(gen)
        self.theme = _combo(["Dark", "Light"], s.value("ui/theme", "Dark", str))
        gf.addRow("Theme:", self.theme)
        self.default_view = _combo(["Tie points", "Point cloud", "Model"], s.value("ui/default_view", "Point cloud", str))
        gf.addRow("Default view:", self.default_view)
        self.qt_dialogs = QCheckBox("Use built-in file dialogs (if the Windows Open/Add dialogs hang)")
        self.qt_dialogs.setChecked(s.value("ui/qt_file_dialogs", False, bool))
        gf.addRow(self.qt_dialogs)
        from .photo_gps import use_photo_gps
        self.dataset = getattr(parent, "dataset", None)
        self.use_photo_gps = QCheckBox("Use Photo GPS")
        self.use_photo_gps.setChecked(use_photo_gps(self.dataset) if self.dataset is not None else True)
        self.use_photo_gps.setToolTip("Use valid photo GPS for pair preselection and camera references. "
                                     "Adding GCPs does not change this setting. Photos remain included when GPS is off.")
        gf.addRow(self.use_photo_gps)
        if self.dataset is not None and "use_photo_gps" not in self.dataset.reference_settings and not self.use_photo_gps.isChecked():
            legacy_note = QLabel("Photo GPS is off to preserve this older project's reference exclusions. "
                                 "Enable Use Photo GPS to use all valid photo positions.")
            legacy_note.setWordWrap(True)
            gf.addRow(legacy_note)
        tabs.addTab(gen, "General")
        gpu = QWidget(); gl = QFormLayout(gpu)
        self.use_gpu = QCheckBox("Use GPU for feature extraction/matching")
        self.use_gpu.setChecked(s.value("gpu/use_gpu", True, bool))
        if not _gpu_ok():
            self.use_gpu.setToolTip("No NVIDIA driver found: COLMAP runs on the CPU "
                                    "(alignment works, slower; dense point cloud needs CUDA)")
        gl.addRow(self.use_gpu)
        tabs.addTab(gpu, "GPU")
        adv = QWidget(); af = QFormLayout(adv)
        row = QHBoxLayout()
        self.colmap = QLineEdit(s.value("colmap/path", "", str))
        self.colmap.setPlaceholderText("auto-detect from PATH")
        b = QPushButton("Browse...")
        b.clicked.connect(self._browse)
        row.addWidget(self.colmap); row.addWidget(b)
        af.addRow("COLMAP executable:", row)
        found = cm.locate_colmap()
        af.addRow("Detected:", QLabel(found or "<i>not found</i>"))
        tabs.addTab(adv, "Advanced")
        lay.addWidget(tabs)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self._save)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _browse(self):
        p, _ = QFileDialog.getOpenFileName(self, "COLMAP executable")
        if p:
            self.colmap.setText(p)

    def _save(self):
        s = QSettings()
        if self.dataset is not None:
            from .photo_gps import use_photo_gps
            changed = use_photo_gps(self.dataset) != self.use_photo_gps.isChecked()
            self.dataset.reference_settings["use_photo_gps"] = self.use_photo_gps.isChecked()
            if changed and self.parent() is not None:
                self.parent().set_modified()
        s.setValue("ui/theme", self.theme.currentText())
        s.setValue("ui/default_view", self.default_view.currentText())
        s.setValue("gpu/use_gpu", self.use_gpu.isChecked())
        s.setValue("ui/qt_file_dialogs", self.qt_dialogs.isChecked())
        from .mainwindow import apply_dialog_setting
        apply_dialog_setting()
        s.setValue("colmap/path", self.colmap.text().strip())
        from .theme import apply_theme
        from PySide6.QtWidgets import QApplication
        apply_theme(QApplication.instance(), self.theme.currentText())
        self.accept()


def _gpu_ok():
    from .colmap import nvidia_driver_present
    return nvidia_driver_present()


def _dspin(lo, hi, val, dec=4, suffix="", special=None):
    from PySide6.QtWidgets import QDoubleSpinBox
    s = QDoubleSpinBox(); s.setDecimals(dec); s.setRange(lo, hi); s.setValue(val)
    if suffix:
        s.setSuffix(suffix)
    if special:
        s.setSpecialValueText(special)
    return s


class _RegionBox(QGroupBox):
    """Optional region (world X/Y bounds) - Metashape's 'Region' setup in 2D."""
    def __init__(self, bounds=None, unit="m"):
        super().__init__("Region")
        self.setCheckable(True); self.setChecked(False)
        f = QFormLayout(self)
        b = bounds or [0, 0, 0, 0]
        self.spins = [_dspin(-1e9, 1e9, float(v), 3, f" {unit}") for v in b]
        f.addRow("X min / Y min:", _pair(self.spins[0], self.spins[1]))
        f.addRow("X max / Y max:", _pair(self.spins[2], self.spins[3]))
        self.setToolTip("Limit the output to these real-world X/Y bounds (project coordinate system)")

    def region(self):
        if not self.isChecked():
            return None
        v = [s.value() for s in self.spins]
        from .workflow import region_checked
        return region_checked(v)


class BuildDEMDialog(_SettingsDialog):
    """Process > Build DEM (from the point cloud or the mesh, see ortho.py)."""
    def __init__(self, parent=None, sources=("Point cloud",), crs="", unit="m", bounds=None, *, ground_only=False):
        super().__init__("Build DTM — classified ground only" if ground_only else "Build DEM", parent)
        st = QSettings()
        self.proj = QLabel(crs or "Local coordinates (model units)"); self.proj.setWordWrap(True)
        self.source = _combo(list(sources), st.value("dem/source", sources[0], str))
        self.interp = _combo(["Enabled (default)", "Disabled", "Extrapolated"],
                             st.value("dem/interp", "Enabled (default)", str))
        self.pixel = _dspin(0, 1e6, 0.0, 4, f" {unit}", "Auto (from point density)")
        self.gform.addRow("Projection:", self.proj)
        self.gform.addRow("Source data:", self.source)
        self.gform.addRow("Interpolation:", self.interp)
        self.aform.addRow("Resolution:", self.pixel)
        self.region_box = _RegionBox(bounds, unit)
        self.content_layout.insertWidget(2, self.region_box)
        from .workflow_ui import dem_context
        dem_context(self, parent, ground_only=ground_only)

    def settings(self):
        st = QSettings()
        st.setValue("dem/source", self.source.currentText()); st.setValue("dem/interp", self.interp.currentText())
        return {"source": self.source.currentText(), "interpolation": self.interp.currentText().replace(" (default)", ""),
                "pixel_size": self.pixel.value(), "region": self.region_box.region(),
                "aggregation": self.aggregation.currentText().lower(), "max_fill": self.max_fill.value(),
                "smooth_distance": self.smooth_distance.value()}


class BuildOrthomosaicDialog(_SettingsDialog):
    """Process > Build Orthomosaic (Metashape-like options, see ortho.py)."""
    def __init__(self, parent=None, surfaces=("Mesh",), crs="", unit="m", gsd=0.0, bounds=None, plan=None):
        super().__init__("Build Orthomosaic", parent)
        from PySide6.QtWidgets import QRadioButton
        st = QSettings()
        self.proj = QLabel((crs or "Local coordinates (model units)") + "  -  Top XY (planar)"); self.proj.setWordWrap(True)
        self.surface = _combo(list(surfaces), st.value("ortho/surface", surfaces[0], str))
        if self.surface.currentText() not in surfaces:
            self.surface.setCurrentIndex(0)
        self.blending = _combo(["Mosaic (default)", "Average", "Single photo (no colour blending)"],
                               st.value("ortho/blending", "Mosaic (default)", str))
        self.holes = QCheckBox("Enable hole filling"); self.holes.setChecked(st.value("ortho/holes", True, bool))
        self.ghost = QCheckBox("Enable ghosting filter"); self.ghost.setChecked(st.value("ortho/ghost", True, bool))
        self.seams = QCheckBox("Refine seamlines"); self.seams.setChecked(st.value("ortho/seams", False, bool))
        self.r_pix = QRadioButton("Pixel size:"); self.r_max = QRadioButton("Max. dimension:")
        self.r_pix.setChecked(True)
        self.gsd = float(gsd or 0)
        self.pixel = _dspin(0, 1e6, self.gsd, 4, f" {unit}", "Auto (photo GSD)")
        self.maxdim = QSpinBox(); self.maxdim.setRange(256, 1_000_000); self.maxdim.setValue(st.value("ortho/maxdim", 16384, int))
        self.maxdim.setSuffix(" px")
        self.gform.addRow("Projection:", self.proj)
        self.gform.addRow("Surface:", self.surface)
        self.gform.addRow("Blending mode:", self.blending)
        self.gform.addRow(self.r_pix, self.pixel)
        self.gform.addRow(self.r_max, self.maxdim)
        if self.gsd:
            self.gsd_label = QLabel(f"Estimated photo GSD ({self.gsd:.4g} {unit}/pix)")
            self.gform.addRow("", self.gsd_label)
        # Metashape-like "Total size (pix)" read-out, checked before the build starts
        self.plan, self.unit = plan, unit
        self.size_label = QLabel(""); self.size_label.setWordWrap(True)
        if plan:
            self.gform.addRow("Total size (pix):", self.size_label)
        for sig in (self.pixel.valueChanged, self.maxdim.valueChanged, self.r_pix.toggled):
            sig.connect(self._update_size)
        self.aform.addRow(self.holes); self.aform.addRow(self.ghost); self.aform.addRow(self.seams)
        self.res = _combo(["Full resolution photos", "Half resolution of each photo"],
                          st.value("ortho/res", "Full resolution photos (best)", str))
        self.aform.addRow("Photo resolution:", self.res)
        self.region_box = _RegionBox(bounds, unit)
        self.content_layout.insertWidget(2, self.region_box)
        self.region_box.toggled.connect(self._update_size)
        for sp in self.region_box.spins:
            sp.valueChanged.connect(self._update_size)
        self._update_size()
        from .workflow_ui import ortho_context
        ortho_context(self, parent)

    def estimated_size(self):
        """(W, H, pixel size) of the result for the current settings, or None."""
        if not self.plan:
            return None
        from .ortho import ortho_extent, raster_size
        try:
            b, off = self.plan["bounds"], self.plan["off"]
            reg = self.region_box.region()
            if reg:
                b = ortho_extent(b[:2], b[2:], None, reg, off[:2])[:4]
            if self.r_max.isChecked():
                px, W, H = raster_size(*b, 1e-12, self.maxdim.value(), off[:2])
            else:
                px = self.pixel.value() or self.gsd
                if px <= 0:
                    return None
                px, W, H = raster_size(*b, px, 0, off[:2])
            return W, H, px
        except Exception:  # noqa: BLE001 - e.g. a region outside the surface
            return None

    def _update_size(self, *_):
        from .ortho import ORTHO_DEFAULTS
        e = self.estimated_size()
        if e is None:
            self.size_label.setText("-"); return
        W, H, px = e
        big = W * H > ORTHO_DEFAULTS["max_pixels"]
        txt = f"~ {W:,} x {H:,}  ({W * H / 1e6:,.0f} Mpx)"
        if big:
            txt += " - too large, increase the pixel size"
        elif self.gsd and px < self.gsd / 1.5:
            txt += f" - finer than the photos ({self.gsd:.4g} {self.unit}/pix)"
        self.size_label.setText(txt)
        self.size_label.setStyleSheet("color: #d04040;" if big else "")

    def settings(self):
        st = QSettings()
        for k, w in (("surface", self.surface), ("blending", self.blending), ("res", self.res)):
            st.setValue(f"ortho/{k}", w.currentText())
        st.setValue("ortho/holes", self.holes.isChecked()); st.setValue("ortho/ghost", self.ghost.isChecked())
        st.setValue("ortho/seams", self.seams.isChecked()); st.setValue("ortho/maxdim", self.maxdim.value())
        use_max = self.r_max.isChecked()
        return {"surface": self.surface.currentText(), "blending": self.blending.currentText().replace(" (default)", "").replace("Single photo (no colour blending)", "Disabled"),
                "hole_filling": self.holes.isChecked(), "ghosting": self.ghost.isChecked(),
                "refine_seamlines": self.seams.isChecked(),
                "pixel_size": 0.0 if use_max else self.pixel.value(),
                "max_dimension": self.maxdim.value() if use_max else 0,
                "max_res": 0, "photo_scale": .5 if self.res.currentIndex() == 1 else 1.0,
                "hole_distance": self.hole_distance.value(), "region": self.region_box.region()}


class ExportRasterDialog(_SettingsDialog):
    """Export > Export Orthomosaic / Export DEM - raster options."""
    def __init__(self, parent=None, kind="ortho", info=None):
        super().__init__("Export DEM" if kind == "dem" else "Export Orthomosaic", parent)
        st = QSettings()
        info = info or {}
        self.kind = kind
        px = info.get("pixel_size") or 0
        self.fmt = _combo(["GeoTIFF (*.tif)"] if kind == "dem" else
                          ["GeoTIFF (*.tif)", "JPEG + world file (*.jpg)", "PNG + world file (*.png)"],
                          st.value(f"export_{kind}/fmt", "GeoTIFF (*.tif)", str))
        self.comp = _combo(["LZW", "Deflate", "None"] + ([] if kind == "dem" else ["JPEG"]),
                           st.value(f"export_{kind}/comp", "LZW", str))
        self.quality = QSpinBox(); self.quality.setRange(10, 100); self.quality.setValue(st.value(f"export_{kind}/q", 90, int))
        self.alpha = QCheckBox("Write alpha channel (otherwise nodata = 0)")
        self.alpha.setChecked(st.value(f"export_{kind}/alpha", True, bool))
        self.ovr = QCheckBox("Write tile overviews"); self.ovr.setChecked(st.value(f"export_{kind}/ovr", True, bool))
        self.big = _combo(["Auto (BigTIFF above 4 GB)", "Yes", "No"])
        levels = int(info.get("levels") or 1)
        self.scale = _combo([f"1/{2 ** k}  ({px * 2 ** k:.4g} m/pix, {info.get('width', 0) // 2 ** k} x "
                             f"{info.get('height', 0) // 2 ** k} px)" for k in range(max(1, min(levels, 6)))])
        self.maxdim = QSpinBox(); self.maxdim.setRange(0, 1_000_000); self.maxdim.setValue(0)
        self.maxdim.setSpecialValueText("No limit"); self.maxdim.setSuffix(" px")
        self.split = QSpinBox(); self.split.setRange(0, 200_000); self.split.setSingleStep(4096)
        self.split.setValue(st.value(f"export_{kind}/split", 0, int)); self.split.setSpecialValueText("No (one file)")
        self.split.setSuffix(" px")
        self.gform.addRow("Format:", self.fmt)
        self.gform.addRow("Resolution:", self.scale)
        self.gform.addRow("Max. dimension:", self.maxdim)
        self.gform.addRow("Split in blocks:", self.split)
        self.aform.addRow("TIFF compression:", self.comp)
        self.aform.addRow("JPEG quality:", self.quality)
        if kind != "dem":
            self.aform.addRow(self.alpha)
        self.aform.addRow(self.ovr)
        self.aform.addRow("Write BigTIFF:", self.big)
        note = QLabel("Coordinates are written in the real world system (offset included): GeoTIFF tags + "
                      "world file (.tfw / .jgw / .pgw)" + ("; a Rhino placement script and notes are written "
                                                          "next to the file." if kind != "dem" else "."))
        note.setWordWrap(True)
        self.content_layout.insertWidget(2, note)

    def ext(self):
        t = self.fmt.currentText()
        return "jpg" if "JPEG" in t else "png" if "PNG" in t else "tif"

    def settings(self):
        st = QSettings()
        k = self.kind
        st.setValue(f"export_{k}/fmt", self.fmt.currentText()); st.setValue(f"export_{k}/comp", self.comp.currentText())
        st.setValue(f"export_{k}/q", self.quality.value()); st.setValue(f"export_{k}/alpha", self.alpha.isChecked())
        st.setValue(f"export_{k}/ovr", self.ovr.isChecked()); st.setValue(f"export_{k}/split", self.split.value())
        return {"fmt": self.ext(), "compression": self.comp.currentText(), "jpeg_quality": self.quality.value(),
                "alpha": self.alpha.isChecked() if k != "dem" else False, "overviews": self.ovr.isChecked(),
                "bigtiff": {0: "auto", 1: "yes", 2: "no"}[self.big.currentIndex()],
                "scale": 2 ** self.scale.currentIndex(), "max_dimension": self.maxdim.value(),
                "split": self.split.value()}


class ImportShapesDialog(_SettingsDialog):
    """Project > Import Data > Import Shapes... - layer, source coordinate system and heights."""
    SRC = ["From file (.prj / KML / GeoJSON)", "Project coordinate system (world)",
           "Project local coordinates (add offset)", "WGS 84 (EPSG::4326)", "WGS 84 / UTM zone", "Custom (WKT / EPSG)"]
    SRC_KEYS = ["file", "project", "local", "wgs84", "utm", "custom"]
    ZMODE = ["Attach to surface (shapes without Z)", "Attach all shapes to surface", "Keep Z from file",
             "Fixed Z for shapes without Z"]
    ZKEYS = ["drape_missing", "drape_all", "keep", "fixed"]

    def __init__(self, parent=None, path="", detected="", project_crs="", surfaces=(), has_shapes=False,
                 notes=(), stats=""):
        super().__init__("Import Shapes", parent)
        import os
        st = QSettings()
        self.layer = QLineEdit(os.path.splitext(os.path.basename(path))[0])
        self.src = _combo(self.SRC)
        self.src.setCurrentIndex(0)
        self.zone = QSpinBox(); self.zone.setRange(1, 60); self.zone.setValue(st.value("shapes/zone", 38, int))
        self.south = QCheckBox("Southern hemisphere")
        self.custom = QLineEdit(); self.custom.setPlaceholderText("EPSG:32638 or PROJCS[...] WKT")
        self.zmode = _combo(self.ZMODE); self.zmode.setCurrentIndex(st.value("shapes/zmode", 0, int))
        self.surface = _combo([s for s in surfaces] or ["(none)"])
        self.fixed = QLineEdit(st.value("shapes/fixed_z", "0", str))
        self.replace = QCheckBox("Replace existing shapes"); self.replace.setEnabled(has_shapes)
        f = QLabel(f"<b>{os.path.basename(path)}</b> - {stats}<br>File coordinate system: {detected or 'not given'}"
                   f"<br>Project: {project_crs}")
        f.setWordWrap(True)
        self.content_layout.insertWidget(0, f)
        self.gform.addRow("Layer name:", self.layer)
        self.gform.addRow("Coordinate system:", self.src)
        utm = QWidget(); h = QHBoxLayout(utm); h.setContentsMargins(0, 0, 0, 0); h.addWidget(self.zone)
        h.addWidget(self.south)
        self.gform.addRow("UTM zone:", utm)
        self.gform.addRow("Custom CRS:", self.custom)
        self.aform.addRow("Heights:", self.zmode)
        self.aform.addRow("Surface:", self.surface)
        self.aform.addRow("Fixed Z (m):", self.fixed)
        self.aform.addRow(self.replace)
        if notes:
            n = QLabel("\n".join(notes[:6])); n.setWordWrap(True); n.setStyleSheet("color: gray")
            self.content_layout.insertWidget(3, n)

    def settings(self):
        st = QSettings()
        st.setValue("shapes/zone", self.zone.value()); st.setValue("shapes/zmode", self.zmode.currentIndex())
        st.setValue("shapes/fixed_z", self.fixed.text())
        try:
            fz = float(self.fixed.text().replace(",", "."))
        except ValueError:
            fz = 0.0
        return {"layer": self.layer.text().strip(), "src": self.SRC_KEYS[self.src.currentIndex()],
                "zone": self.zone.value(), "south": self.south.isChecked(), "custom": self.custom.text().strip(),
                "z_mode": self.ZKEYS[self.zmode.currentIndex()], "surface": self.surface.currentText(),
                "fixed_z": fz, "replace": self.replace.isChecked()}


class ExportShapesDialog(_SettingsDialog):
    """Export > Export Shapes... - format, coordinate system, layers."""
    FMTS = ["Shapefile (*.shp)", "AutoCAD DXF R12 (*.dxf)", "GeoJSON (*.geojson)"]

    def __init__(self, parent=None, layers=(), systems=()):
        super().__init__("Export Shapes", parent)
        st = QSettings()
        self.fmt = _combo(self.FMTS, st.value("shapes/export_fmt", self.FMTS[0], str))
        self.crs = _combo(list(systems) or ["Project coordinate system"])
        self.gform.addRow("Format:", self.fmt)
        self.gform.addRow("Coordinate system:", self.crs)
        self.checks = []
        for name, n, vis in layers:
            c = QCheckBox(f"{name} ({n})"); c.setChecked(True); c.layer_name = name
            self.aform.addRow(c); self.checks.append(c)
        note = QLabel("Coordinates are written in the real world system (offset included). Shapefiles get a .prj "
                      "for georeferenced projects; mixed geometry types are split into _points / _lines / "
                      "_polygons files.")
        note.setWordWrap(True)
        self.content_layout.insertWidget(2, note)

    def ext(self):
        t = self.fmt.currentText()
        return "dxf" if "DXF" in t else "geojson" if "GeoJSON" in t else "shp"

    def settings(self):
        QSettings().setValue("shapes/export_fmt", self.fmt.currentText())
        return {"fmt": self.ext(), "crs_index": self.crs.currentIndex(), "crs": self.crs.currentText(),
                "layers": [c.layer_name for c in self.checks if c.isChecked()]}
